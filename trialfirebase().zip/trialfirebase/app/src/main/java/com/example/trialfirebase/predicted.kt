package com.example.trialfirebase

import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup.LayoutParams
import android.widget.Button
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class predicted : AppCompatActivity() {

    private var containerDataList: Array<*>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.predicted)

        containerDataList = intent.getSerializableExtra("containerDataList") as? Array<*>
        val tableLayout = findViewById<TableLayout>(R.id.tableLayout)

        val button1 = findViewById<Button>(R.id.button1)
        val button2 = findViewById<Button>(R.id.button2)

        button1.setOnClickListener {
            displayContainerData("location 1", tableLayout)
        }

        button2.setOnClickListener {
            displayContainerData("location 2", tableLayout)
        }
    }


    private fun displayContainerData(location: String, tableLayout: TableLayout) {
        tableLayout.removeAllViews() // Clear existing table rows

        containerDataList?.forEach { containerData ->
            if (containerData is Map<*, *>) {
                val containerLocation = containerData["location"].toString()
                if (containerLocation == location) {
                    val id = containerData["id"].toString()
                    val dest = containerData["destinations"].toString()
                    val type = containerData["cargo_type"].toString()
                    val weight = containerData["cargo_weight"].toString()

                    val row = TableRow(this)

                    val idTextView = createTextView(id)
                    row.addView(idTextView)

                    val destTextView = createTextView(dest)
                    row.addView(destTextView)

                    val typeTextView = createTextView(type)
                    row.addView(typeTextView)

                    val weightTextView = createTextView(weight)
                    row.addView(weightTextView)

                    val locationTextView = createTextView(location)
                    row.addView(locationTextView)

                    tableLayout.addView(row)
                }
            }
        }
    }



    private fun createTextView(text: String): TextView {
        val textView = TextView(this)
        textView.text = text
        textView.gravity = Gravity.CENTER
        val layoutParams = TableRow.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
        textView.layoutParams = layoutParams
        return textView
    }
}